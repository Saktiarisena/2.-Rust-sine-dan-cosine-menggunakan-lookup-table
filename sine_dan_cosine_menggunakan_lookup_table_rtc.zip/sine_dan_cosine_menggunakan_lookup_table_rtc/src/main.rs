use std::f64::consts::PI;

struct Trigonometry {
    // Lookup table untuk sudut 0-90 derajat (sin, cos)
    lookup_table: [(f64, f64); 91],
}

impl Trigonometry {
    fn new() -> Self {
        // Isi lookup table (contoh sederhana, bisa diganti dengan nilai lebih presisi)
        let mut table = [(0.0, 0.0); 91];
        for degrees in 0..=90 {
            let rad = (degrees as f64).to_radians();
            table[degrees as usize] = (rad.sin(), rad.cos());
        }
        
        Self { lookup_table: table }
    }

    // Konversi derajat ke radian
    fn to_radians(&self, degrees: f64) -> f64 {
        degrees * PI / 180.0
    }

    // Mencari sin dari lookup table dengan handling kuadran
    fn sin(&self, degrees: f64) -> f64 {
        let degrees = degrees % 360.0;
        let degrees = if degrees < 0.0 { degrees + 360.0 } else { degrees };
        
        match degrees {
            d if d <= 90.0 => self.lookup_table[d as usize].0,
            d if d <= 180.0 => self.lookup_table[(180.0 - d) as usize].0,
            d if d <= 270.0 => -self.lookup_table[(d - 180.0) as usize].0,
            _ => -self.lookup_table[(360.0 - degrees) as usize].0,
        }
    }

    // Mencari cos dari lookup table dengan handling kuadran
    fn cos(&self, degrees: f64) -> f64 {
        let degrees = degrees % 360.0;
        let degrees = if degrees < 0.0 { degrees + 360.0 } else { degrees };
        
        match degrees {
            d if d <= 90.0 => self.lookup_table[d as usize].1,
            d if d <= 180.0 => -self.lookup_table[(180.0 - d) as usize].1,
            d if d <= 270.0 => -self.lookup_table[(d - 180.0) as usize].1,
            _ => self.lookup_table[(360.0 - degrees) as usize].1,
        }
    }

    // Menampilkan tabel trigonometri
    fn print_table(&self, start: f64, end: f64, step: f64) {
        println!("| Degrees | Radians    | sin(x)     | cos(x)     |");
        println!("|---------|------------|------------|------------|");
        
        let mut degrees = start;
        while degrees <= end {
            let radians = self.to_radians(degrees);
            println!("| {:>7.1} | {:>10.6} | {:>10.6} | {:>10.6} |",
                degrees,
                radians,
                self.sin(degrees),
                self.cos(degrees)
            );
            degrees += step;
        }
    }
}

fn main() {
    let trig = Trigonometry::new();
    
    // Contoh penggunaan
    println!("sin(30°) = {}", trig.sin(30.0));
    println!("cos(45°) = {}", trig.cos(45.0));
    
    // Bandingkan dengan nilai standar Rust
    println!("Rust std: sin(30°) = {}", trig.to_radians(30.0).sin());
    
    // Cetak tabel
    trig.print_table(0.0, 360.0, 15.0);
}